/**

 *Submitted for verification at Etherscan.io on 2022-05-06

*/



//// SPDX-License-Identifier: UNLICENSED



pragma solidity ^0.8.0;



/**

 * @title Counters

 * @author Matt Condon (@shrugs)

 * @dev Provides counters that can only be incremented, decremented or reset. This can be used e.g. to track the number

 * of elements in a mapping, issuing ERC721 ids, or counting request ids.

 *

 * Include with `using Counters for Counters.Counter;`

 */

library Counters {

    struct Counter {

        // This variable should never be directly accessed by users of the library: interactions must be restricted to

        // the library's function. As of Solidity v0.5.2, this cannot be enforced, though there is a proposal to add

        // this feature: see https://github.com/ethereum/solidity/issues/4637

        uint256 _value; // default: 0

    }



    function current(Counter storage counter) internal view returns (uint256) {

        return counter._value;

    }



    function increment(Counter storage counter) internal {

        unchecked {

            counter._value += 1;

        }

    }



    function decrement(Counter storage counter) internal {

        uint256 value = counter._value;

        require(value > 0, "Counter: decrement overflow");

        unchecked {

            counter._value = value - 1;

        }

    }



    function reset(Counter storage counter) internal {

        counter._value = 0;

    }

}







// File: @openzeppelin/contracts/utils/Context.sol



pragma solidity ^0.8.0;



/*

 * @dev Provides information about the current execution context, including the

 * sender of the transaction and its data. While these are generally available

 * via msg.sender and msg.data, they should not be accessed in such a direct

 * manner, since when dealing with meta-transactions the account sending and

 * paying for execution may not be the actual sender (as far as an application

 * is concerned).

 *

 * This contract is only required for intermediate, library-like contracts.

 */

abstract contract Context {

    function _msgSender() internal view virtual returns (address) {

        return msg.sender;

    }



    function _msgData() internal view virtual returns (bytes calldata) {

        return msg.data;

    }

}



// File: @openzeppelin/contracts/utils/introspection/IERC165.sol



pragma solidity ^0.8.0;



/**

 * @dev Interface of the ERC165 standard, as defined in the

 * https://eips.ethereum.org/EIPS/eip-165[EIP].

 *

 * Implementers can declare support of contract interfaces, which can then be

 * queried by others ({ERC165Checker}).

 *

 * For an implementation, see {ERC165}.

 */

interface IERC165 {

    /**

     * @dev Returns true if this contract implements the interface defined by

     * `interfaceId`. See the corresponding

     * https://eips.ethereum.org/EIPS/eip-165#how-interfaces-are-identified[EIP section]

     * to learn more about how these ids are created.

     *

     * This function call must use less than 30 000 gas.

     */

    function supportsInterface(bytes4 interfaceId) external view returns (bool);

}



// OpenZeppelin Contracts v4.4.1 (security/ReentrancyGuard.sol)



pragma solidity ^0.8.0;



/**

 * @dev Contract module that helps prevent reentrant calls to a function.

 *

 * Inheriting from `ReentrancyGuard` will make the {nonReentrant} modifier

 * available, which can be applied to functions to make sure there are no nested

 * (reentrant) calls to them.

 *

 * Note that because there is a single `nonReentrant` guard, functions marked as

 * `nonReentrant` may not call one another. This can be worked around by making

 * those functions `private`, and then adding `external` `nonReentrant` entry

 * points to them.

 *

 * TIP: If you would like to learn more about reentrancy and alternative ways

 * to protect against it, check out our blog post

 * https://blog.openzeppelin.com/reentrancy-after-istanbul/[Reentrancy After Istanbul].

 */

abstract contract ReentrancyGuard {

    // Booleans are more expensive than uint256 or any type that takes up a full

    // word because each write operation emits an extra SLOAD to first read the

    // slot's contents, replace the bits taken up by the boolean, and then write

    // back. This is the compiler's defense against contract upgrades and

    // pointer aliasing, and it cannot be disabled.



    // The values being non-zero value makes deployment a bit more expensive,

    // but in exchange the refund on every call to nonReentrant will be lower in

    // amount. Since refunds are capped to a percentage of the total

    // transaction's gas, it is best to keep them low in cases like this one, to

    // increase the likelihood of the full refund coming into effect.

    uint256 private constant _NOT_ENTERED = 1;

    uint256 private constant _ENTERED = 2;



    uint256 private _status;



    constructor() {

        _status = _NOT_ENTERED;

    }



    /**

     * @dev Prevents a contract from calling itself, directly or indirectly.

     * Calling a `nonReentrant` function from another `nonReentrant`

     * function is not supported. It is possible to prevent this from happening

     * by making the `nonReentrant` function external, and making it call a

     * `private` function that does the actual work.

     */

    modifier nonReentrant() {

        // On the first call to nonReentrant, _notEntered will be true

        require(_status != _ENTERED, "ReentrancyGuard: reentrant call");



        // Any calls to nonReentrant after this point will fail

        _status = _ENTERED;



        _;



        // By storing the original value once again, a refund is triggered (see

        // https://eips.ethereum.org/EIPS/eip-2200)

        _status = _NOT_ENTERED;

    }

}



// File: @openzeppelin/contracts/token/ERC721/IERC721.sol



pragma solidity ^0.8.0;



/**

 * @dev Required interface of an ERC721 compliant contract.

 */

interface IERC721 is IERC165 {

    /**

     * @dev Emitted when `tokenId` token is transferred from `from` to `to`.

     */

    event Transfer(

        address indexed from,

        address indexed to,

        uint256 indexed tokenId

    );



    /**

     * @dev Emitted when `owner` enables `approved` to manage the `tokenId` token.

     */

    event Approval(

        address indexed owner,

        address indexed approved,

        uint256 indexed tokenId

    );



    /**

     * @dev Emitted when `owner` enables or disables (`approved`) `operator` to manage all of its assets.

     */

    event ApprovalForAll(

        address indexed owner,

        address indexed operator,

        bool approved

    );



    /**

     * @dev Returns the number of tokens in ``owner``'s account.

     */

    function balanceOf(address owner) external view returns (uint256 balance);



    /**

     * @dev Returns the owner of the `tokenId` token.

     *

     * Requirements:

     *

     * - `tokenId` must exist.

     */

    function ownerOf(uint256 tokenId) external view returns (address owner);



    /**

     * @dev Safely transfers `tokenId` token from `from` to `to`, checking first that contract recipients

     * are aware of the ERC721 protocol to prevent tokens from being forever locked.

     *

     * Requirements:

     *

     * - `from` cannot be the zero address.

     * - `to` cannot be the zero address.

     * - `tokenId` token must exist and be owned by `from`.

     * - If the caller is not `from`, it must be have been allowed to move this token by either {approve} or {setApprovalForAll}.

     * - If `to` refers to a smart contract, it must implement {IERC721Receiver-onERC721Received}, which is called upon a safe transfer.

     *

     * Emits a {Transfer} event.

     */

    function safeTransferFrom(

        address from,

        address to,

        uint256 tokenId

    ) external;



    /**

     * @dev Transfers `tokenId` token from `from` to `to`.

     *

     * WARNING: Usage of this method is discouraged, use {safeTransferFrom} whenever possible.

     *

     * Requirements:

     *

     * - `from` cannot be the zero address.

     * - `to` cannot be the zero address.

     * - `tokenId` token must be owned by `from`.

     * - If the caller is not `from`, it must be approved to move this token by either {approve} or {setApprovalForAll}.

     *

     * Emits a {Transfer} event.

     */

    function transferFrom(

        address from,

        address to,

        uint256 tokenId

    ) external;



    /**

     * @dev Gives permission to `to` to transfer `tokenId` token to another account.

     * The approval is cleared when the token is transferred.

     *

     * Only a single account can be approved at a time, so approving the zero address clears previous approvals.

     *

     * Requirements:

     *

     * - The caller must own the token or be an approved operator.

     * - `tokenId` must exist.

     *

     * Emits an {Approval} event.

     */

    function approve(address to, uint256 tokenId) external;



    /**

     * @dev Returns the account approved for `tokenId` token.

     *

     * Requirements:

     *

     * - `tokenId` must exist.

     */

    function getApproved(uint256 tokenId)

        external

        view

        returns (address operator);



    /**

     * @dev Approve or remove `operator` as an operator for the caller.

     * Operators can call {transferFrom} or {safeTransferFrom} for any token owned by the caller.

     *

     * Requirements:

     *

     * - The `operator` cannot be the caller.

     *

     * Emits an {ApprovalForAll} event.

     */

    function setApprovalForAll(address operator, bool _approved) external;



    /**

     * @dev Returns if the `operator` is allowed to manage all of the assets of `owner`.

     *

     * See {setApprovalForAll}

     */

    function isApprovedForAll(address owner, address operator)

        external

        view

        returns (bool);



    /**

     * @dev Safely transfers `tokenId` token from `from` to `to`.

     *

     * Requirements:

     *

     * - `from` cannot be the zero address.

     * - `to` cannot be the zero address.

     * - `tokenId` token must exist and be owned by `from`.

     * - If the caller is not `from`, it must be approved to move this token by either {approve} or {setApprovalForAll}.

     * - If `to` refers to a smart contract, it must implement {IERC721Receiver-onERC721Received}, which is called upon a safe transfer.

     *

     * Emits a {Transfer} event.

     */

    function safeTransferFrom(

        address from,

        address to,

        uint256 tokenId,

        bytes calldata data

    ) external;

}



// File: @openzeppelin/contracts/access/Ownable.sol



pragma solidity ^0.8.0;



/**

 * @dev Contract module which provides a basic access control mechanism, where

 * there is an account (an owner) that can be granted exclusive access to

 * specific functions.

 *

 * By default, the owner account will be the one that deploys the contract. This

 * can later be changed with {transferOwnership}.

 *

 * This module is used through inheritance. It will make available the modifier

 * `onlyOwner`, which can be applied to your functions to restrict their use to

 * the owner.

 */

abstract contract Ownable is Context {

    address private _owner;



    event OwnershipTransferred(

        address indexed previousOwner,

        address indexed newOwner

    );



    /**

     * @dev Initializes the contract setting the deployer as the initial owner.

     */

    constructor() {

        _setOwner(_msgSender());

    }



    /**

     * @dev Returns the address of the current owner.

     */

    function owner() public view virtual returns (address) {

        return _owner;

    }



    /**

     * @dev Throws if called by any account other than the owner.

     */

    modifier onlyOwner() {

        require(owner() == _msgSender(), "Ownable: caller is not the owner");

        _;

    }



    /**

     * @dev Leaves the contract without owner. It will not be possible to call

     * `onlyOwner` functions anymore. Can only be called by the current owner.

     *

     * NOTE: Renouncing ownership will leave the contract without an owner,

     * thereby removing any functionality that is only available to the owner.

     */

    function renounceOwnership() public virtual onlyOwner {

        _setOwner(address(0));

    }



    /**

     * @dev Transfers ownership of the contract to a new account (`newOwner`).

     * Can only be called by the current owner.

     */

    function transferOwnership(address newOwner) public virtual onlyOwner {

        require(

            newOwner != address(0),

            "Ownable: new owner is the zero address"

        );

        _setOwner(newOwner);

    }



    function _setOwner(address newOwner) private {

        address oldOwner = _owner;

        _owner = newOwner;

        emit OwnershipTransferred(oldOwner, newOwner);

    }

}



// File: @openzeppelin/contracts/token/ERC721/extensions/IERC721Enumerable.sol



pragma solidity ^0.8.0;



/**

 * @title ERC-721 Non-Fungible Token Standard, optional enumeration extension

 * @dev See https://eips.ethereum.org/EIPS/eip-721

 */

interface IERC721Enumerable is IERC721 {

    /**

     * @dev Returns the total amount of tokens stored by the contract.

     */

    function totalSupply() external view returns (uint256);



    /**

     * @dev Returns a token ID owned by `owner` at a given `index` of its token list.

     * Use along with {balanceOf} to enumerate all of ``owner``'s tokens.

     */

    function tokenOfOwnerByIndex(address owner, uint256 index)

        external

        view

        returns (uint256 tokenId);



    /**

     * @dev Returns a token ID at a given `index` of all the tokens stored by the contract.

     * Use along with {totalSupply} to enumerate all tokens.

     */

    function tokenByIndex(uint256 index) external view returns (uint256);

}



// File: @openzeppelin/contracts/utils/introspection/ERC165.sol



pragma solidity ^0.8.0;



/**

 * @dev Implementation of the {IERC165} interface.

 *

 * Contracts that want to implement ERC165 should inherit from this contract and override {supportsInterface} to check

 * for the additional interface id that will be supported. For example:

 *

 * ```solidity

 * function supportsInterface(bytes4 interfaceId) public view virtual override returns (bool) {

 *     return interfaceId == type(MyInterface).interfaceId || super.supportsInterface(interfaceId);

 * }

 * ```

 *

 * Alternatively, {ERC165Storage} provides an easier to use but more expensive implementation.

 */

abstract contract ERC165 is IERC165 {

    /**

     * @dev See {IERC165-supportsInterface}.

     */

    function supportsInterface(bytes4 interfaceId)

        public

        view

        virtual

        override

        returns (bool)

    {

        return interfaceId == type(IERC165).interfaceId;

    }

}



// File: @openzeppelin/contracts/utils/Strings.sol



pragma solidity ^0.8.0;



/**

 * @dev String operations.

 */

library Strings {

    bytes16 private constant _HEX_SYMBOLS = "0123456789abcdef";



    /**

     * @dev Converts a `uint256` to its ASCII `string` decimal representation.

     */

    function toString(uint256 value) internal pure returns (string memory) {

        // Inspired by OraclizeAPI's implementation - MIT licence

        // https://github.com/oraclize/ethereum-api/blob/b42146b063c7d6ee1358846c198246239e9360e8/oraclizeAPI_0.4.25.sol



        if (value == 0) {

            return "0";

        }

        uint256 temp = value;

        uint256 digits;

        while (temp != 0) {

            digits++;

            temp /= 10;

        }

        bytes memory buffer = new bytes(digits);

        while (value != 0) {

            digits -= 1;

            buffer[digits] = bytes1(uint8(48 + uint256(value % 10)));

            value /= 10;

        }

        return string(buffer);

    }



    /**

     * @dev Converts a `uint256` to its ASCII `string` hexadecimal representation.

     */

    function toHexString(uint256 value) internal pure returns (string memory) {

        if (value == 0) {

            return "0x00";

        }

        uint256 temp = value;

        uint256 length = 0;

        while (temp != 0) {

            length++;

            temp >>= 8;

        }

        return toHexString(value, length);

    }



    /**

     * @dev Converts a `uint256` to its ASCII `string` hexadecimal representation with fixed length.

     */

    function toHexString(uint256 value, uint256 length)

        internal

        pure

        returns (string memory)

    {

        bytes memory buffer = new bytes(2 * length + 2);

        buffer[0] = "0";

        buffer[1] = "x";

        for (uint256 i = 2 * length + 1; i > 1; --i) {

            buffer[i] = _HEX_SYMBOLS[value & 0xf];

            value >>= 4;

        }

        require(value == 0, "Strings: hex length insufficient");

        return string(buffer);

    }

}



// File: @openzeppelin/contracts/utils/Address.sol



pragma solidity ^0.8.0;



/**

 * @dev Collection of functions related to the address type

 */

library Address {

    /**

     * @dev Returns true if `account` is a contract.

     *

     * [IMPORTANT]

     * ====

     * It is unsafe to assume that an address for which this function returns

     * false is an externally-owned account (EOA) and not a contract.

     *

     * Among others, `isContract` will return false for the following

     * types of addresses:

     *

     *  - an externally-owned account

     *  - a contract in construction

     *  - an address where a contract will be created

     *  - an address where a contract lived, but was destroyed

     * ====

     */

    function isContract(address account) internal view returns (bool) {

        // This method relies on extcodesize, which returns 0 for contracts in

        // construction, since the code is only stored at the end of the

        // constructor execution.



        uint256 size;

        assembly {

            size := extcodesize(account)

        }

        return size > 0;

    }



    /**

     * @dev Replacement for Solidity's `transfer`: sends `amount` wei to

     * `recipient`, forwarding all available gas and reverting on errors.

     *

     * https://eips.ethereum.org/EIPS/eip-1884[EIP1884] increases the gas cost

     * of certain opcodes, possibly making contracts go over the 2300 gas limit

     * imposed by `transfer`, making them unable to receive funds via

     * `transfer`. {sendValue} removes this limitation.

     *

     * https://diligence.consensys.net/posts/2019/09/stop-using-soliditys-transfer-now/[Learn more].

     *

     * IMPORTANT: because control is transferred to `recipient`, care must be

     * taken to not create reentrancy vulnerabilities. Consider using

     * {ReentrancyGuard} or the

     * https://solidity.readthedocs.io/en/v0.5.11/security-considerations.html#use-the-checks-effects-interactions-pattern[checks-effects-interactions pattern].

     */

    function sendValue(address payable recipient, uint256 amount) internal {

        require(

            address(this).balance >= amount,

            "Address: insufficient balance"

        );



        (bool success, ) = recipient.call{value: amount}("");

        require(

            success,

            "Address: unable to send value, recipient may have reverted"

        );

    }



    /**

     * @dev Performs a Solidity function call using a low level `call`. A

     * plain `call` is an unsafe replacement for a function call: use this

     * function instead.

     *

     * If `target` reverts with a revert reason, it is bubbled up by this

     * function (like regular Solidity function calls).

     *

     * Returns the raw returned data. To convert to the expected return value,

     * use https://solidity.readthedocs.io/en/latest/units-and-global-variables.html?highlight=abi.decode#abi-encoding-and-decoding-functions[`abi.decode`].

     *

     * Requirements:

     *

     * - `target` must be a contract.

     * - calling `target` with `data` must not revert.

     *

     * _Available since v3.1._

     */

    function functionCall(address target, bytes memory data)

        internal

        returns (bytes memory)

    {

        return functionCall(target, data, "Address: low-level call failed");

    }



    /**

     * @dev Same as {xref-Address-functionCall-address-bytes-}[`functionCall`], but with

     * `errorMessage` as a fallback revert reason when `target` reverts.

     *

     * _Available since v3.1._

     */

    function functionCall(

        address target,

        bytes memory data,

        string memory errorMessage

    ) internal returns (bytes memory) {

        return functionCallWithValue(target, data, 0, errorMessage);

    }



    /**

     * @dev Same as {xref-Address-functionCall-address-bytes-}[`functionCall`],

     * but also transferring `value` wei to `target`.

     *

     * Requirements:

     *

     * - the calling contract must have an ETH balance of at least `value`.

     * - the called Solidity function must be `payable`.

     *

     * _Available since v3.1._

     */

    function functionCallWithValue(

        address target,

        bytes memory data,

        uint256 value

    ) internal returns (bytes memory) {

        return

            functionCallWithValue(

                target,

                data,

                value,

                "Address: low-level call with value failed"

            );

    }



    /**

     * @dev Same as {xref-Address-functionCallWithValue-address-bytes-uint256-}[`functionCallWithValue`], but

     * with `errorMessage` as a fallback revert reason when `target` reverts.

     *

     * _Available since v3.1._

     */

    function functionCallWithValue(

        address target,

        bytes memory data,

        uint256 value,

        string memory errorMessage

    ) internal returns (bytes memory) {

        require(

            address(this).balance >= value,

            "Address: insufficient balance for call"

        );

        require(isContract(target), "Address: call to non-contract");



        (bool success, bytes memory returndata) = target.call{value: value}(

            data

        );

        return _verifyCallResult(success, returndata, errorMessage);

    }



    /**

     * @dev Same as {xref-Address-functionCall-address-bytes-}[`functionCall`],

     * but performing a static call.

     *

     * _Available since v3.3._

     */

    function functionStaticCall(address target, bytes memory data)

        internal

        view

        returns (bytes memory)

    {

        return

            functionStaticCall(

                target,

                data,

                "Address: low-level static call failed"

            );

    }



    /**

     * @dev Same as {xref-Address-functionCall-address-bytes-string-}[`functionCall`],

     * but performing a static call.

     *

     * _Available since v3.3._

     */

    function functionStaticCall(

        address target,

        bytes memory data,

        string memory errorMessage

    ) internal view returns (bytes memory) {

        require(isContract(target), "Address: static call to non-contract");



        (bool success, bytes memory returndata) = target.staticcall(data);

        return _verifyCallResult(success, returndata, errorMessage);

    }



    /**

     * @dev Same as {xref-Address-functionCall-address-bytes-}[`functionCall`],

     * but performing a delegate call.

     *

     * _Available since v3.4._

     */

    function functionDelegateCall(address target, bytes memory data)

        internal

        returns (bytes memory)

    {

        return

            functionDelegateCall(

                target,

                data,

                "Address: low-level delegate call failed"

            );

    }



    /**

     * @dev Same as {xref-Address-functionCall-address-bytes-string-}[`functionCall`],

     * but performing a delegate call.

     *

     * _Available since v3.4._

     */

    function functionDelegateCall(

        address target,

        bytes memory data,

        string memory errorMessage

    ) internal returns (bytes memory) {

        require(isContract(target), "Address: delegate call to non-contract");



        (bool success, bytes memory returndata) = target.delegatecall(data);

        return _verifyCallResult(success, returndata, errorMessage);

    }



    function _verifyCallResult(

        bool success,

        bytes memory returndata,

        string memory errorMessage

    ) private pure returns (bytes memory) {

        if (success) {

            return returndata;

        } else {

            // Look for revert reason and bubble it up if present

            if (returndata.length > 0) {

                // The easiest way to bubble the revert reason is using memory via assembly



                assembly {

                    let returndata_size := mload(returndata)

                    revert(add(32, returndata), returndata_size)

                }

            } else {

                revert(errorMessage);

            }

        }

    }

}



// File: @openzeppelin/contracts/token/ERC721/extensions/IERC721Metadata.sol



pragma solidity ^0.8.0;



/**

 * @title ERC-721 Non-Fungible Token Standard, optional metadata extension

 * @dev See https://eips.ethereum.org/EIPS/eip-721

 */

interface IERC721Metadata is IERC721 {

    /**

     * @dev Returns the token collection name.

     */

    function name() external view returns (string memory);



    /**

     * @dev Returns the token collection symbol.

     */

    function symbol() external view returns (string memory);



    /**

     * @dev Returns the Uniform Resource Identifier (URI) for `tokenId` token.

     */

    function tokenURI(uint256 tokenId) external view returns (string memory);

}



// File: @openzeppelin/contracts/token/ERC721/IERC721Receiver.sol



pragma solidity ^0.8.0;



/**

 * @title ERC721 token receiver interface

 * @dev Interface for any contract that wants to support safeTransfers

 * from ERC721 asset contracts.

 */

interface IERC721Receiver {

    /**

     * @dev Whenever an {IERC721} `tokenId` token is transferred to this contract via {IERC721-safeTransferFrom}

     * by `operator` from `from`, this function is called.

     *

     * It must return its Solidity selector to confirm the token transfer.

     * If any other value is returned or the interface is not implemented by the recipient, the transfer will be reverted.

     *

     * The selector can be obtained in Solidity with `IERC721.onERC721Received.selector`.

     */

    function onERC721Received(

        address operator,

        address from,

        uint256 tokenId,

        bytes calldata data

    ) external returns (bytes4);

}



pragma solidity ^0.8.0;



/**

* @dev Implementation of https://eips.ethereum.org/EIPS/eip-721[ERC721] Non-Fungible Token Standard, including

* the Metadata and Enumerable extension. Built to optimize for lower gas during batch mints.

*

* Assumes serials are sequentially minted starting at 0 (e.g. 0, 1, 2, 3..).

*

* Assumes the number of issuable tokens (collection size) is capped and fits in a uint128.

*

* Does not support burning tokens to address(0).

*/

contract ERC721A is

Context,

ERC165,

IERC721,

IERC721Metadata,

IERC721Enumerable

{

    using Address for address;

    using Strings for uint256;



    struct TokenOwnership {

        address addr;

        uint64 startTimestamp;

    }



    struct AddressData {

        uint128 balance;

        uint128 numberMinted;

    }



    uint256 private currentIndex = 0;



    uint256 internal immutable collectionSize;

    uint256 internal immutable maxBatchSize;



    // Token name

    string private _name;



    // Token symbol

    string private _symbol;



    // Mapping from token ID to ownership details

    // An empty struct value does not necessarily mean the token is unowned. See ownershipOf implementation for details.

    mapping(uint256 => TokenOwnership) private _ownerships;



    // Mapping owner address to address data

    mapping(address => AddressData) private _addressData;



    // Mapping from token ID to approved address

    mapping(uint256 => address) private _tokenApprovals;



    // Mapping from owner to operator approvals

    mapping(address => mapping(address => bool)) private _operatorApprovals;



    /**

    * @dev

    * `maxBatchSize` refers to how much a minter can mint at a time.

    * `collectionSize_` refers to how many tokens are in the collection.

    */

    constructor(

        string memory name_,

        string memory symbol_,

        uint256 maxBatchSize_,

        uint256 collectionSize_

    ) {

        require(

        collectionSize_ > 0,

        "ERC721A: collection must have a nonzero supply"

        );

        require(maxBatchSize_ > 0, "ERC721A: max batch size must be nonzero");

        _name = name_;

        _symbol = symbol_;

        maxBatchSize = maxBatchSize_;

        collectionSize = collectionSize_;

    }



    /**

    * @dev See {IERC721Enumerable-totalSupply}.

    */

    function totalSupply() public view override returns (uint256) {

        return currentIndex;

    }



    /**

    * @dev See {IERC721Enumerable-tokenByIndex}.

    */

    function tokenByIndex(uint256 index) public view override returns (uint256) {

        require(index < totalSupply(), "ERC721A: global index out of bounds");

        return index;

    }



    /**

    * @dev See {IERC721Enumerable-tokenOfOwnerByIndex}.

    * This read function is O(collectionSize). If calling from a separate contract, be sure to test gas first.

    * It may also degrade with extremely large collection sizes (e.g >> 10000), test for your use case.

    */

    function tokenOfOwnerByIndex(address owner, uint256 index)

        public

        view

        override

        returns (uint256)

    {

        require(index < balanceOf(owner), "ERC721A: owner index out of bounds");

        uint256 numMintedSoFar = totalSupply();

        uint256 tokenIdsIdx = 0;

        address currOwnershipAddr = address(0);

        for (uint256 i = 0; i < numMintedSoFar; i++) {

        TokenOwnership memory ownership = _ownerships[i];

        if (ownership.addr != address(0)) {

            currOwnershipAddr = ownership.addr;

        }

        if (currOwnershipAddr == owner) {

            if (tokenIdsIdx == index) {

            return i;

            }

            tokenIdsIdx++;

        }

        }

        revert("ERC721A: unable to get token of owner by index");

    }



    /**

    * @dev See {IERC165-supportsInterface}.

    */

    function supportsInterface(bytes4 interfaceId)

        public

        view

        virtual

        override(ERC165, IERC165)

        returns (bool)

    {

        return

        interfaceId == type(IERC721).interfaceId ||

        interfaceId == type(IERC721Metadata).interfaceId ||

        interfaceId == type(IERC721Enumerable).interfaceId ||

        super.supportsInterface(interfaceId);

    }



    /**

    * @dev See {IERC721-balanceOf}.

    */

    function balanceOf(address owner) public view override returns (uint256) {

        require(owner != address(0), "ERC721A: balance query for the zero address");

        return uint256(_addressData[owner].balance);

    }



    function _numberMinted(address owner) internal view returns (uint256) {

        require(

        owner != address(0),

        "ERC721A: number minted query for the zero address"

        );

        return uint256(_addressData[owner].numberMinted);

    }



    function ownershipOf(uint256 tokenId)

        internal

        view

        returns (TokenOwnership memory)

    {

        require(_exists(tokenId), "ERC721A: owner query for nonexistent token");



        uint256 lowestTokenToCheck;

        if (tokenId >= maxBatchSize) {

        lowestTokenToCheck = tokenId - maxBatchSize + 1;

        }



        for (uint256 curr = tokenId; curr >= lowestTokenToCheck; curr--) {

        TokenOwnership memory ownership = _ownerships[curr];

        if (ownership.addr != address(0)) {

            return ownership;

        }

        }



        revert("ERC721A: unable to determine the owner of token");

    }



    /**

    * @dev See {IERC721-ownerOf}.

    */

    function ownerOf(uint256 tokenId) public view override returns (address) {

        return ownershipOf(tokenId).addr;

    }



    /**

    * @dev See {IERC721Metadata-name}.

    */

    function name() public view virtual override returns (string memory) {

        return _name;

    }



    /**

    * @dev See {IERC721Metadata-symbol}.

    */

    function symbol() public view virtual override returns (string memory) {

        return _symbol;

    }



    /**

    * @dev See {IERC721Metadata-tokenURI}.

    */

    function tokenURI(uint256 tokenId)

        public

        view

        virtual

        override

        returns (string memory)

    {

        require(

        _exists(tokenId),

        "ERC721Metadata: URI query for nonexistent token"

        );



        string memory baseURI = _baseURI();

        return

        bytes(baseURI).length > 0

            ? string(abi.encodePacked(baseURI, tokenId.toString()))

            : "";

    }



    /**

    * @dev Base URI for computing {tokenURI}. If set, the resulting URI for each

    * token will be the concatenation of the `baseURI` and the `tokenId`. Empty

    * by default, can be overriden in child contracts.

    */

    function _baseURI() internal view virtual returns (string memory) {

        return "";

    }



    /**

    * @dev See {IERC721-approve}.

    */

    function approve(address to, uint256 tokenId) public override {

        address owner = ERC721A.ownerOf(tokenId);

        require(to != owner, "ERC721A: approval to current owner");



        require(

        _msgSender() == owner || isApprovedForAll(owner, _msgSender()),

        "ERC721A: approve caller is not owner nor approved for all"

        );



        _approve(to, tokenId, owner);

    }



    /**

    * @dev See {IERC721-getApproved}.

    */

    function getApproved(uint256 tokenId) public view override returns (address) {

        require(_exists(tokenId), "ERC721A: approved query for nonexistent token");



        return _tokenApprovals[tokenId];

    }



    /**

    * @dev See {IERC721-setApprovalForAll}.

    */

    function setApprovalForAll(address operator, bool approved) public override {

        require(operator != _msgSender(), "ERC721A: approve to caller");



        _operatorApprovals[_msgSender()][operator] = approved;

        emit ApprovalForAll(_msgSender(), operator, approved);

    }



    /**

    * @dev See {IERC721-isApprovedForAll}.

    */

    function isApprovedForAll(address owner, address operator)

        public

        view

        virtual

        override

        returns (bool)

    {

        return _operatorApprovals[owner][operator];

    }



    /**

    * @dev See {IERC721-transferFrom}.

    */

    function transferFrom(

        address from,

        address to,

        uint256 tokenId

    ) public override {

        _transfer(from, to, tokenId);

    }



    /**

    * @dev See {IERC721-safeTransferFrom}.

    */

    function safeTransferFrom(

        address from,

        address to,

        uint256 tokenId

    ) public override {

        safeTransferFrom(from, to, tokenId, "");

    }



    /**

    * @dev See {IERC721-safeTransferFrom}.

    */

    function safeTransferFrom(

        address from,

        address to,

        uint256 tokenId,

        bytes memory _data

    ) public override {

        _transfer(from, to, tokenId);

        require(

        _checkOnERC721Received(from, to, tokenId, _data),

        "ERC721A: transfer to non ERC721Receiver implementer"

        );

    }



    /**

    * @dev Returns whether `tokenId` exists.

    *

    * Tokens can be managed by their owner or approved accounts via {approve} or {setApprovalForAll}.

    *

    * Tokens start existing when they are minted (`_mint`),

    */

    function _exists(uint256 tokenId) internal view returns (bool) {

        return tokenId < currentIndex;

    }



    function _safeMint(address to, uint256 quantity) internal {

        _safeMint(to, quantity, "");

    }



    /**

    * @dev Mints `quantity` tokens and transfers them to `to`.

    *

    * Requirements:

    *

    * - there must be `quantity` tokens remaining unminted in the total collection.

    * - `to` cannot be the zero address.

    * - `quantity` cannot be larger than the max batch size.

    *

    * Emits a {Transfer} event.

    */

    function _safeMint(

        address to,

        uint256 quantity,

        bytes memory _data

    ) internal {

        uint256 startTokenId = currentIndex;

        require(to != address(0), "ERC721A: mint to the zero address");

        // We know if the first token in the batch doesn't exist, the other ones don't as well, because of serial ordering.

        require(!_exists(startTokenId), "ERC721A: token already minted");

        require(quantity <= maxBatchSize, "ERC721A: quantity to mint too high");



        _beforeTokenTransfers(address(0), to, startTokenId, quantity);



        AddressData memory addressData = _addressData[to];

        _addressData[to] = AddressData(

        addressData.balance + uint128(quantity),

        addressData.numberMinted + uint128(quantity)

        );

        _ownerships[startTokenId] = TokenOwnership(to, uint64(block.timestamp));



        uint256 updatedIndex = startTokenId;



        for (uint256 i = 0; i < quantity; i++) {

        emit Transfer(address(0), to, updatedIndex);

        require(

            _checkOnERC721Received(address(0), to, updatedIndex, _data),

            "ERC721A: transfer to non ERC721Receiver implementer"

        );

        updatedIndex++;

        }



        currentIndex = updatedIndex;

        _afterTokenTransfers(address(0), to, startTokenId, quantity);

    }



    /**

    * @dev Transfers `tokenId` from `from` to `to`.

    *

    * Requirements:

    *

    * - `to` cannot be the zero address.

    * - `tokenId` token must be owned by `from`.

    *

    * Emits a {Transfer} event.

    */

    function _transfer(

        address from,

        address to,

        uint256 tokenId

    ) private {

        TokenOwnership memory prevOwnership = ownershipOf(tokenId);



        bool isApprovedOrOwner = (_msgSender() == prevOwnership.addr ||

        getApproved(tokenId) == _msgSender() ||

        isApprovedForAll(prevOwnership.addr, _msgSender()));



        require(

        isApprovedOrOwner,

        "ERC721A: transfer caller is not owner nor approved"

        );



        require(

        prevOwnership.addr == from,

        "ERC721A: transfer from incorrect owner"

        );

        require(to != address(0), "ERC721A: transfer to the zero address");



        _beforeTokenTransfers(from, to, tokenId, 1);



        // Clear approvals from the previous owner

        _approve(address(0), tokenId, prevOwnership.addr);



        _addressData[from].balance -= 1;

        _addressData[to].balance += 1;

        _ownerships[tokenId] = TokenOwnership(to, uint64(block.timestamp));



        // If the ownership slot of tokenId+1 is not explicitly set, that means the transfer initiator owns it.

        // Set the slot of tokenId+1 explicitly in storage to maintain correctness for ownerOf(tokenId+1) calls.

        uint256 nextTokenId = tokenId + 1;

        if (_ownerships[nextTokenId].addr == address(0)) {

        if (_exists(nextTokenId)) {

            _ownerships[nextTokenId] = TokenOwnership(

            prevOwnership.addr,

            prevOwnership.startTimestamp

            );

        }

        }



        emit Transfer(from, to, tokenId);

        _afterTokenTransfers(from, to, tokenId, 1);

    }



    /**

    * @dev Approve `to` to operate on `tokenId`

    *

    * Emits a {Approval} event.

    */

    function _approve(

        address to,

        uint256 tokenId,

        address owner

    ) private {

        _tokenApprovals[tokenId] = to;

        emit Approval(owner, to, tokenId);

    }



    uint256 public nextOwnerToExplicitlySet = 0;



    /**

    * @dev Explicitly set `owners` to eliminate loops in future calls of ownerOf().

    */

    function _setOwnersExplicit(uint256 quantity) internal {

        uint256 oldNextOwnerToSet = nextOwnerToExplicitlySet;

        require(quantity > 0, "quantity must be nonzero");

        uint256 endIndex = oldNextOwnerToSet + quantity - 1;

        if (endIndex > collectionSize - 1) {

        endIndex = collectionSize - 1;

        }

        // We know if the last one in the group exists, all in the group exist, due to serial ordering.

        require(_exists(endIndex), "not enough minted yet for this cleanup");

        for (uint256 i = oldNextOwnerToSet; i <= endIndex; i++) {

        if (_ownerships[i].addr == address(0)) {

            TokenOwnership memory ownership = ownershipOf(i);

            _ownerships[i] = TokenOwnership(

            ownership.addr,

            ownership.startTimestamp

            );

        }

        }

        nextOwnerToExplicitlySet = endIndex + 1;

    }



    /**

    * @dev Internal function to invoke {IERC721Receiver-onERC721Received} on a target address.

    * The call is not executed if the target address is not a contract.

    *

    * @param from address representing the previous owner of the given token ID

    * @param to target address that will receive the tokens

    * @param tokenId uint256 ID of the token to be transferred

    * @param _data bytes optional data to send along with the call

    * @return bool whether the call correctly returned the expected magic value

    */

    function _checkOnERC721Received(

        address from,

        address to,

        uint256 tokenId,

        bytes memory _data

    ) private returns (bool) {

        if (to.isContract()) {

        try

            IERC721Receiver(to).onERC721Received(_msgSender(), from, tokenId, _data)

        returns (bytes4 retval) {

            return retval == IERC721Receiver(to).onERC721Received.selector;

        } catch (bytes memory reason) {

            if (reason.length == 0) {

            revert("ERC721A: transfer to non ERC721Receiver implementer");

            } else {

            assembly {

                revert(add(32, reason), mload(reason))

            }

            }

        }

        } else {

        return true;

        }

    }



    /**

    * @dev Hook that is called before a set of serially-ordered token ids are about to be transferred. This includes minting.

    *

    * startTokenId - the first token id to be transferred

    * quantity - the amount to be transferred

    *

    * Calling conditions:

    *

    * - When `from` and `to` are both non-zero, ``from``'s `tokenId` will be

    * transferred to `to`.

    * - When `from` is zero, `tokenId` will be minted for `to`.

    */

    function _beforeTokenTransfers(

        address from,

        address to,

        uint256 startTokenId,

        uint256 quantity

    ) internal virtual {}



    /**

    * @dev Hook that is called after a set of serially-ordered token ids have been transferred. This includes

    * minting.

    *

    * startTokenId - the first token id to be transferred

    * quantity - the amount to be transferred

    *

    * Calling conditions:

    *

    * - when `from` and `to` are both non-zero.

    * - `from` and `to` are never both zero.

    */

    function _afterTokenTransfers(

        address from,

        address to,

        uint256 startTokenId,

        uint256 quantity

    ) internal virtual {}

}





library Ballots {

    struct Ballot {

        uint256 _nOption;

        uint256[] _poll;

        mapping(address => bool) _voters;

        bool _isOpen;

    }



    function currentPoll(Ballot storage ballot) internal view returns (uint256[] memory) {

        return ballot._poll;

    }



    function createNewPoll(Ballot storage ballot, uint256 _nOption) internal {

        ballot._poll = new uint256[](_nOption);

        ballot._nOption = _nOption;

    }



    function vote(Ballot storage ballot, uint256 _option, uint256 _voteCount) internal {

        require(

            ballot._voters[msg.sender] == false,

            "Already Voted"

        );

        require(

            ballot._isOpen == true,

            "Poll is closed"

        );

        ballot._poll[_option] += _voteCount;

        ballot._voters[msg.sender] = true;

    }



    function closePoll(Ballot storage ballot) internal {

        ballot._isOpen = false;

    }



    function reopenPoll(Ballot storage ballot) internal {

        ballot._isOpen = true;

    }

}





// File: contracts/CelestialSecrets.sol



contract CelestialSecrets is ERC721A, Ownable, ReentrancyGuard {

    using Counters for Counters.Counter;

    using Ballots for Ballots.Ballot;

    using Strings for uint256;



    Ballots.Ballot[] private ballots;

    Counters.Counter private totalBallots;



    enum SellState { Paused, Whitelist, Public }



    SellState public currentSellState;

    string public baseTokenURI;



    uint256 public constant MAX_SUPPLY = 5555;

    uint256 public maxMint = 10;

    uint256 public reservedForCoreTeam;

    uint256 public currentMintCost = 0.03 ether;

    uint256 public totalWithdraw;



    bool public isRevealed = false;

    string public baseExtension = ".json";



    mapping(address => bool) whitelistedAddresses;





    constructor(string memory baseURI, uint256 coreTeamReserved) ERC721A("CelestialSecrets", "CLST", maxMint, MAX_SUPPLY) {

        setBaseURI(baseURI);

        reservedForCoreTeam = coreTeamReserved;

        currentSellState = SellState.Paused;

    }



    // Cost Functions



    function setMintCost(uint256 _cost) public onlyOwner {

        // _cost is in wei

        currentMintCost = _cost;

    }





    // Whitelist Functions



    function addWhitelistedUser(address[] calldata _users)

        external

        onlyOwner

    {

        for (uint256 i = 0; i < _users.length; i++) {

            require(_users[i] != address(0), "Can't add the null address");

            whitelistedAddresses[_users[i]] = true;

        }

    }



    function removeWhitelistedUser(address[] calldata _users)

        external

        onlyOwner

    {

        for (uint256 i = 0; i < _users.length; i++) {

            require(_users[i] != address(0), "Can't remove the null address");

            whitelistedAddresses[_users[i]] = false;

        }

    }



    function verifyWhitelistedUser(address _user) external view returns(bool) {

        return whitelistedAddresses[_user];

    }





    // Update SaleState (Pause/Whitelist/Public)



    function setSellState(uint256 _state) external onlyOwner {

        if (_state == 0) {

            currentSellState = SellState.Paused;

        } else if (_state == 1) {

            currentSellState = SellState.Whitelist;

            setMintCost(30000000000000000);

        }

        else if (_state == 2) {

            currentSellState = SellState.Public;

            setMintCost(40000000000000000);

        }

    }

    

    // Minting Functions



    function mintCelestialSecrets(uint256 _mintAmount) external payable {

        // Raise error if SellState is Paused

        require(

            currentSellState != SellState.Paused, 

            "Minting is currently paused"

        );



        // Raise error if trying to mint less than 1 or more than 5

        require(

            _mintAmount > 0 && _mintAmount <= maxMint,

            "Can only mint minimum 1 and maximum 10"

        );



        // Check if user is whitelisted

        bool isUserWhitelisted = whitelistedAddresses[msg.sender];



        // Raise error currently whitelist sell but user not whitelisted

        if (currentSellState == SellState.Whitelist) {

            require(

                isUserWhitelisted == true,

                "User is not whitelisted"

            );

        }



        // Get Price

        uint256 mintPrice;

        if (isUserWhitelisted && currentMintCost > 30000000000000000) {

            mintPrice = 30000000000000000;

        } else {

            mintPrice = currentMintCost;

        }





        // Raise error if not enough fund

        require(

            msg.value >= mintPrice * _mintAmount,

            "Insufficient fund"

        );



        // Raise error if out of supply

        require(

            totalSupply() + _mintAmount <= MAX_SUPPLY,

            "Insufficient supply"

        );



        _safeMint(msg.sender, _mintAmount);

    }



    function mintForCoreTeam(uint256 _mintAmount) external onlyOwner {

        require(

            _mintAmount % maxMint == 0,

            "can only mint a multiple of the maxBatchSize"

        );

        uint256 nLoop = _mintAmount / maxMint;

        for (uint256 i = 0; i < nLoop; i++) {

            _safeMint(msg.sender, maxMint);

        }

        reservedForCoreTeam = reservedForCoreTeam - _mintAmount;

    }



    // Withdraw Functions



    function withdraw() public onlyOwner {

        uint256 amount = address(this).balance;

        (bool os, ) = payable(owner()).call{value: address(this).balance}("");

        require(os);

        totalWithdraw += amount;

    }



    // Airdrop Functions



    function airdrop(address[] calldata _addresses, uint256 airdropPerWallet) external onlyOwner {

        require(

            totalSupply() + _addresses.length <= MAX_SUPPLY,

            "Airdrop will exceed maximum supply"

        );

        for (uint256 i = 0; i < _addresses.length; i++) {

            require(_addresses[i] != address(0), "Airdrop to Null address");

            _safeMint(_addresses[i], airdropPerWallet);

        }

    }



    // Voting



    modifier pollIdentifierCompliance(uint256 _pollNumber) {

        require(

            0 < _pollNumber && _pollNumber <= totalBallots.current(),

            "Invalid Poll Number"

        );

        _;

    }



    function startNewPoll(uint256 _nOptions) external onlyOwner {

        Ballots.Ballot storage newBallot = ballots.push();

        newBallot.createNewPoll(_nOptions);

        totalBallots.increment();

    }

    

    function vote(uint256 _pollNumber, uint256 _option) external pollIdentifierCompliance(_pollNumber) {

        ballots[_pollNumber-1].vote(_option, balanceOf(msg.sender));

    }



    function getVotes(uint256 _pollNumber) external view pollIdentifierCompliance(_pollNumber) returns (uint256[] memory) {

        return ballots[_pollNumber-1].currentPoll();

    }



    function getTotalBallots() external view returns (uint256) {

        return totalBallots.current();

    }



    function closeGivenPoll(uint256 _pollNumber) external onlyOwner pollIdentifierCompliance(_pollNumber) {

        ballots[_pollNumber-1].closePoll();

    }



    function reopoenGivenPoll(uint256 _pollNumber) external onlyOwner pollIdentifierCompliance(_pollNumber) {

        ballots[_pollNumber-1].reopenPoll();

    }



    // Reveal



    function setBaseExtension(string memory _newExtension) public onlyOwner {

        baseExtension = _newExtension;

    }



    function _baseURI() internal view virtual override returns (string memory) {

        return baseTokenURI;

    }



    function setRevealed(bool _state) public onlyOwner {

        isRevealed = _state;

    }



    function setBaseURI(string memory baseURI) public onlyOwner {

        baseTokenURI = baseURI;

    }



    function tokenURI(uint256 tokenId) public view virtual override returns (string memory)

    {

        require(

        _exists(tokenId),

        "ERC721Metadata: URI query for nonexistent token"

        );



        string memory baseURI = _baseURI();

        return

        bytes(baseURI).length > 0

            ? string(abi.encodePacked(baseURI, tokenId.toString(), baseExtension))

            : "";

    }

}