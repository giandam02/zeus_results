// File: @openzeppelin/contracts/token/ERC20/IERC20.sol



// SPDX-License-Identifier: MIT



pragma solidity ^0.6.0;



/**

 * @dev Interface of the ERC20 standard as defined in the EIP.

 */

interface IERC20 {

    /**

     * @dev Returns the amount of tokens in existence.

     */

    function totalSupply() external view returns (uint256);



    /**

     * @dev Returns the amount of tokens owned by `account`.

     */

    function balanceOf(address account) external view returns (uint256);



    /**

     * @dev Moves `amount` tokens from the caller's account to `recipient`.

     *

     * Returns a boolean value indicating whether the operation succeeded.

     *

     * Emits a {Transfer} event.

     */

    function transfer(address recipient, uint256 amount) external returns (bool);



    /**

     * @dev Returns the remaining number of tokens that `spender` will be

     * allowed to spend on behalf of `owner` through {transferFrom}. This is

     * zero by default.

     *

     * This value changes when {approve} or {transferFrom} are called.

     */

    function allowance(address owner, address spender) external view returns (uint256);



    /**

     * @dev Sets `amount` as the allowance of `spender` over the caller's tokens.

     *

     * Returns a boolean value indicating whether the operation succeeded.

     *

     * IMPORTANT: Beware that changing an allowance with this method brings the risk

     * that someone may use both the old and the new allowance by unfortunate

     * transaction ordering. One possible solution to mitigate this race

     * condition is to first reduce the spender's allowance to 0 and set the

     * desired value afterwards:

     * https://github.com/ethereum/EIPs/issues/20#issuecomment-263524729

     *

     * Emits an {Approval} event.

     */

    function approve(address spender, uint256 amount) external returns (bool);



    /**

     * @dev Moves `amount` tokens from `sender` to `recipient` using the

     * allowance mechanism. `amount` is then deducted from the caller's

     * allowance.

     *

     * Returns a boolean value indicating whether the operation succeeded.

     *

     * Emits a {Transfer} event.

     */

    function transferFrom(address sender, address recipient, uint256 amount) external returns (bool);



    /**

     * @dev Emitted when `value` tokens are moved from one account (`from`) to

     * another (`to`).

     *

     * Note that `value` may be zero.

     */

    event Transfer(address indexed from, address indexed to, uint256 value);



    /**

     * @dev Emitted when the allowance of a `spender` for an `owner` is set by

     * a call to {approve}. `value` is the new allowance.

     */

    event Approval(address indexed owner, address indexed spender, uint256 value);

}



// File: @openzeppelin/contracts/math/SafeMath.sol







pragma solidity ^0.6.0;



/**

 * @dev Wrappers over Solidity's arithmetic operations with added overflow

 * checks.

 *

 * Arithmetic operations in Solidity wrap on overflow. This can easily result

 * in bugs, because programmers usually assume that an overflow raises an

 * error, which is the standard behavior in high level programming languages.

 * `SafeMath` restores this intuition by reverting the transaction when an

 * operation overflows.

 *

 * Using this library instead of the unchecked operations eliminates an entire

 * class of bugs, so it's recommended to use it always.

 */

library SafeMath {

    /**

     * @dev Returns the addition of two unsigned integers, reverting on

     * overflow.

     *

     * Counterpart to Solidity's `+` operator.

     *

     * Requirements:

     *

     * - Addition cannot overflow.

     */

    function add(uint256 a, uint256 b) internal pure returns (uint256) {

        uint256 c = a + b;

        require(c >= a, "SafeMath: addition overflow");



        return c;

    }



    /**

     * @dev Returns the subtraction of two unsigned integers, reverting on

     * overflow (when the result is negative).

     *

     * Counterpart to Solidity's `-` operator.

     *

     * Requirements:

     *

     * - Subtraction cannot overflow.

     */

    function sub(uint256 a, uint256 b) internal pure returns (uint256) {

        return sub(a, b, "SafeMath: subtraction overflow");

    }



    /**

     * @dev Returns the subtraction of two unsigned integers, reverting with custom message on

     * overflow (when the result is negative).

     *

     * Counterpart to Solidity's `-` operator.

     *

     * Requirements:

     *

     * - Subtraction cannot overflow.

     */

    function sub(uint256 a, uint256 b, string memory errorMessage) internal pure returns (uint256) {

        require(b <= a, errorMessage);

        uint256 c = a - b;



        return c;

    }



    /**

     * @dev Returns the multiplication of two unsigned integers, reverting on

     * overflow.

     *

     * Counterpart to Solidity's `*` operator.

     *

     * Requirements:

     *

     * - Multiplication cannot overflow.

     */

    function mul(uint256 a, uint256 b) internal pure returns (uint256) {

        // Gas optimization: this is cheaper than requiring 'a' not being zero, but the

        // benefit is lost if 'b' is also tested.

        // See: https://github.com/OpenZeppelin/openzeppelin-contracts/pull/522

        if (a == 0) {

            return 0;

        }



        uint256 c = a * b;

        require(c / a == b, "SafeMath: multiplication overflow");



        return c;

    }



    /**

     * @dev Returns the integer division of two unsigned integers. Reverts on

     * division by zero. The result is rounded towards zero.

     *

     * Counterpart to Solidity's `/` operator. Note: this function uses a

     * `revert` opcode (which leaves remaining gas untouched) while Solidity

     * uses an invalid opcode to revert (consuming all remaining gas).

     *

     * Requirements:

     *

     * - The divisor cannot be zero.

     */

    function div(uint256 a, uint256 b) internal pure returns (uint256) {

        return div(a, b, "SafeMath: division by zero");

    }



    /**

     * @dev Returns the integer division of two unsigned integers. Reverts with custom message on

     * division by zero. The result is rounded towards zero.

     *

     * Counterpart to Solidity's `/` operator. Note: this function uses a

     * `revert` opcode (which leaves remaining gas untouched) while Solidity

     * uses an invalid opcode to revert (consuming all remaining gas).

     *

     * Requirements:

     *

     * - The divisor cannot be zero.

     */

    function div(uint256 a, uint256 b, string memory errorMessage) internal pure returns (uint256) {

        require(b > 0, errorMessage);

        uint256 c = a / b;

        // assert(a == b * c + a % b); // There is no case in which this doesn't hold



        return c;

    }



    /**

     * @dev Returns the remainder of dividing two unsigned integers. (unsigned integer modulo),

     * Reverts when dividing by zero.

     *

     * Counterpart to Solidity's `%` operator. This function uses a `revert`

     * opcode (which leaves remaining gas untouched) while Solidity uses an

     * invalid opcode to revert (consuming all remaining gas).

     *

     * Requirements:

     *

     * - The divisor cannot be zero.

     */

    function mod(uint256 a, uint256 b) internal pure returns (uint256) {

        return mod(a, b, "SafeMath: modulo by zero");

    }



    /**

     * @dev Returns the remainder of dividing two unsigned integers. (unsigned integer modulo),

     * Reverts with custom message when dividing by zero.

     *

     * Counterpart to Solidity's `%` operator. This function uses a `revert`

     * opcode (which leaves remaining gas untouched) while Solidity uses an

     * invalid opcode to revert (consuming all remaining gas).

     *

     * Requirements:

     *

     * - The divisor cannot be zero.

     */

    function mod(uint256 a, uint256 b, string memory errorMessage) internal pure returns (uint256) {

        require(b != 0, errorMessage);

        return a % b;

    }

}



// File: @openzeppelin/contracts/utils/Address.sol







pragma solidity ^0.6.2;



/**

 * @dev Collection of functions related to the address type

 */

library Address {

    /**

     * @dev Returns true if `account` is a contract.

     *

     * [IMPORTANT]

     * ====

     * It is unsafe to assume that an address for which this function returns

     * false is an externally-owned account (EOA) and not a contract.

     *

     * Among others, `isContract` will return false for the following

     * types of addresses:

     *

     *  - an externally-owned account

     *  - a contract in construction

     *  - an address where a contract will be created

     *  - an address where a contract lived, but was destroyed

     * ====

     */

    function isContract(address account) internal view returns (bool) {

        // This method relies in extcodesize, which returns 0 for contracts in

        // construction, since the code is only stored at the end of the

        // constructor execution.



        uint256 size;

        // solhint-disable-next-line no-inline-assembly

        assembly { size := extcodesize(account) }

        return size > 0;

    }



    /**

     * @dev Replacement for Solidity's `transfer`: sends `amount` wei to

     * `recipient`, forwarding all available gas and reverting on errors.

     *

     * https://eips.ethereum.org/EIPS/eip-1884[EIP1884] increases the gas cost

     * of certain opcodes, possibly making contracts go over the 2300 gas limit

     * imposed by `transfer`, making them unable to receive funds via

     * `transfer`. {sendValue} removes this limitation.

     *

     * https://diligence.consensys.net/posts/2019/09/stop-using-soliditys-transfer-now/[Learn more].

     *

     * IMPORTANT: because control is transferred to `recipient`, care must be

     * taken to not create reentrancy vulnerabilities. Consider using

     * {ReentrancyGuard} or the

     * https://solidity.readthedocs.io/en/v0.5.11/security-considerations.html#use-the-checks-effects-interactions-pattern[checks-effects-interactions pattern].

     */

    function sendValue(address payable recipient, uint256 amount) internal {

        require(address(this).balance >= amount, "Address: insufficient balance");



        // solhint-disable-next-line avoid-low-level-calls, avoid-call-value

        (bool success, ) = recipient.call{ value: amount }("");

        require(success, "Address: unable to send value, recipient may have reverted");

    }



    /**

     * @dev Performs a Solidity function call using a low level `call`. A

     * plain`call` is an unsafe replacement for a function call: use this

     * function instead.

     *

     * If `target` reverts with a revert reason, it is bubbled up by this

     * function (like regular Solidity function calls).

     *

     * Returns the raw returned data. To convert to the expected return value,

     * use https://solidity.readthedocs.io/en/latest/units-and-global-variables.html?highlight=abi.decode#abi-encoding-and-decoding-functions[`abi.decode`].

     *

     * Requirements:

     *

     * - `target` must be a contract.

     * - calling `target` with `data` must not revert.

     *

     * _Available since v3.1._

     */

    function functionCall(address target, bytes memory data) internal returns (bytes memory) {

      return functionCall(target, data, "Address: low-level call failed");

    }



    /**

     * @dev Same as {xref-Address-functionCall-address-bytes-}[`functionCall`], but with

     * `errorMessage` as a fallback revert reason when `target` reverts.

     *

     * _Available since v3.1._

     */

    function functionCall(address target, bytes memory data, string memory errorMessage) internal returns (bytes memory) {

        return _functionCallWithValue(target, data, 0, errorMessage);

    }



    /**

     * @dev Same as {xref-Address-functionCall-address-bytes-}[`functionCall`],

     * but also transferring `value` wei to `target`.

     *

     * Requirements:

     *

     * - the calling contract must have an ETH balance of at least `value`.

     * - the called Solidity function must be `payable`.

     *

     * _Available since v3.1._

     */

    function functionCallWithValue(address target, bytes memory data, uint256 value) internal returns (bytes memory) {

        return functionCallWithValue(target, data, value, "Address: low-level call with value failed");

    }



    /**

     * @dev Same as {xref-Address-functionCallWithValue-address-bytes-uint256-}[`functionCallWithValue`], but

     * with `errorMessage` as a fallback revert reason when `target` reverts.

     *

     * _Available since v3.1._

     */

    function functionCallWithValue(address target, bytes memory data, uint256 value, string memory errorMessage) internal returns (bytes memory) {

        require(address(this).balance >= value, "Address: insufficient balance for call");

        return _functionCallWithValue(target, data, value, errorMessage);

    }



    function _functionCallWithValue(address target, bytes memory data, uint256 weiValue, string memory errorMessage) private returns (bytes memory) {

        require(isContract(target), "Address: call to non-contract");



        // solhint-disable-next-line avoid-low-level-calls

        (bool success, bytes memory returndata) = target.call{ value: weiValue }(data);

        if (success) {

            return returndata;

        } else {

            // Look for revert reason and bubble it up if present

            if (returndata.length > 0) {

                // The easiest way to bubble the revert reason is using memory via assembly



                // solhint-disable-next-line no-inline-assembly

                assembly {

                    let returndata_size := mload(returndata)

                    revert(add(32, returndata), returndata_size)

                }

            } else {

                revert(errorMessage);

            }

        }

    }

}



// File: @openzeppelin/contracts/token/ERC20/SafeERC20.sol







pragma solidity ^0.6.0;









/**

 * @title SafeERC20

 * @dev Wrappers around ERC20 operations that throw on failure (when the token

 * contract returns false). Tokens that return no value (and instead revert or

 * throw on failure) are also supported, non-reverting calls are assumed to be

 * successful.

 * To use this library you can add a `using SafeERC20 for IERC20;` statement to your contract,

 * which allows you to call the safe operations as `token.safeTransfer(...)`, etc.

 */

library SafeERC20 {

    using SafeMath for uint256;

    using Address for address;



    function safeTransfer(IERC20 token, address to, uint256 value) internal {

        _callOptionalReturn(token, abi.encodeWithSelector(token.transfer.selector, to, value));

    }



    function safeTransferFrom(IERC20 token, address from, address to, uint256 value) internal {

        _callOptionalReturn(token, abi.encodeWithSelector(token.transferFrom.selector, from, to, value));

    }



    /**

     * @dev Deprecated. This function has issues similar to the ones found in

     * {IERC20-approve}, and its usage is discouraged.

     *

     * Whenever possible, use {safeIncreaseAllowance} and

     * {safeDecreaseAllowance} instead.

     */

    function safeApprove(IERC20 token, address spender, uint256 value) internal {

        // safeApprove should only be called when setting an initial allowance,

        // or when resetting it to zero. To increase and decrease it, use

        // 'safeIncreaseAllowance' and 'safeDecreaseAllowance'

        // solhint-disable-next-line max-line-length

        require((value == 0) || (token.allowance(address(this), spender) == 0),

            "SafeERC20: approve from non-zero to non-zero allowance"

        );

        _callOptionalReturn(token, abi.encodeWithSelector(token.approve.selector, spender, value));

    }



    function safeIncreaseAllowance(IERC20 token, address spender, uint256 value) internal {

        uint256 newAllowance = token.allowance(address(this), spender).add(value);

        _callOptionalReturn(token, abi.encodeWithSelector(token.approve.selector, spender, newAllowance));

    }



    function safeDecreaseAllowance(IERC20 token, address spender, uint256 value) internal {

        uint256 newAllowance = token.allowance(address(this), spender).sub(value, "SafeERC20: decreased allowance below zero");

        _callOptionalReturn(token, abi.encodeWithSelector(token.approve.selector, spender, newAllowance));

    }



    /**

     * @dev Imitates a Solidity high-level call (i.e. a regular function call to a contract), relaxing the requirement

     * on the return value: the return value is optional (but if data is returned, it must not be false).

     * @param token The token targeted by the call.

     * @param data The call data (encoded using abi.encode or one of its variants).

     */

    function _callOptionalReturn(IERC20 token, bytes memory data) private {

        // We need to perform a low level call here, to bypass Solidity's return data size checking mechanism, since

        // we're implementing it ourselves. We use {Address.functionCall} to perform this call, which verifies that

        // the target address contains contract code and also asserts for success in the low-level call.



        bytes memory returndata = address(token).functionCall(data, "SafeERC20: low-level call failed");

        if (returndata.length > 0) { // Return data is optional

            // solhint-disable-next-line max-line-length

            require(abi.decode(returndata, (bool)), "SafeERC20: ERC20 operation did not succeed");

        }

    }

}



// File: @openzeppelin/contracts/GSN/Context.sol







pragma solidity ^0.6.0;



/*

 * @dev Provides information about the current execution context, including the

 * sender of the transaction and its data. While these are generally available

 * via msg.sender and msg.data, they should not be accessed in such a direct

 * manner, since when dealing with GSN meta-transactions the account sending and

 * paying for execution may not be the actual sender (as far as an application

 * is concerned).

 *

 * This contract is only required for intermediate, library-like contracts.

 */

abstract contract Context {

    function _msgSender() internal view virtual returns (address payable) {

        return msg.sender;

    }



    function _msgData() internal view virtual returns (bytes memory) {

        this; // silence state mutability warning without generating bytecode - see https://github.com/ethereum/solidity/issues/2691

        return msg.data;

    }

}



// File: @openzeppelin/contracts/access/Ownable.sol







pragma solidity ^0.6.0;



/**

 * @dev Contract module which provides a basic access control mechanism, where

 * there is an account (an owner) that can be granted exclusive access to

 * specific functions.

 *

 * By default, the owner account will be the one that deploys the contract. This

 * can later be changed with {transferOwnership}.

 *

 * This module is used through inheritance. It will make available the modifier

 * `onlyOwner`, which can be applied to your functions to restrict their use to

 * the owner.

 */

contract Ownable is Context {

    address private _owner;



    event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);



    /**

     * @dev Initializes the contract setting the deployer as the initial owner.

     */

    constructor () internal {

        address msgSender = _msgSender();

        _owner = msgSender;

        emit OwnershipTransferred(address(0), msgSender);

    }



    /**

     * @dev Returns the address of the current owner.

     */

    function owner() public view returns (address) {

        return _owner;

    }



    /**

     * @dev Throws if called by any account other than the owner.

     */

    modifier onlyOwner() {

        require(_owner == _msgSender(), "Ownable: caller is not the owner");

        _;

    }



    /**

     * @dev Leaves the contract without owner. It will not be possible to call

     * `onlyOwner` functions anymore. Can only be called by the current owner.

     *

     * NOTE: Renouncing ownership will leave the contract without an owner,

     * thereby removing any functionality that is only available to the owner.

     */

    function renounceOwnership() public virtual onlyOwner {

        emit OwnershipTransferred(_owner, address(0));

        _owner = address(0);

    }



    /**

     * @dev Transfers ownership of the contract to a new account (`newOwner`).

     * Can only be called by the current owner.

     */

    function transferOwnership(address newOwner) public virtual onlyOwner {

        require(newOwner != address(0), "Ownable: new owner is the zero address");

        emit OwnershipTransferred(_owner, newOwner);

        _owner = newOwner;

    }

}



// File: contracts/interfaces/IVault.sol







pragma solidity >=0.5.0 <0.7.0;



interface IVault {

  function update(uint256) external;

}



// File: contracts/farms/ERC20Farm.sol







pragma solidity >=0.5.0 <0.7.0;













contract ERC20Farm is IVault, Ownable {

  using SafeMath for uint256;

  using SafeERC20 for IERC20;



  event Deposit(address indexed user, uint256 indexed pid, uint256 amount);

  event Withdraw(address indexed user, uint256 indexed pid, uint256 amount);

  event ClaimedRewards(

    address indexed user,

    uint256 indexed pid,

    uint256 amount

  );

  event EmergencyWithdraw(

    address indexed user,

    uint256 indexed pid,

    uint256 amount

  );



  /// @notice Detail of each user.

  struct UserInfo {

    uint256 amount; // How many tokens the user has provided.

    uint256 rewardDebt; // Reward debt. See explanation below.

    //

    // We do some fancy math here. Basically, any point in time, the amount of reward

    // entitled to a user which is pending to be distributed is:

    //

    // pending reward = (user.amount * pool.accRewardPerShare) - user.rewardDebt

    //

    // Whenever a user deposits or withdraws tokens to a pool:

    //   1. The pool's `accRewardPerShare` (and `lastRewardBlock`) gets updated.

    //   2. User receives the pending reward sent to their address.

    //   3. User's `amount` gets updated.

    //   4. User's `rewardDebt` gets updated.

  }



  /// @notice Detail of each pool.

  struct PoolInfo {

    address token; // Token to stake.

    uint256 allocPoint; // How many allocation points assigned to this pool. Rewards to distribute per block.

    uint256 accRewardPerShare; // Accumulated rewards per share.

  }



  /// @dev Reward token balance minus any pending rewards.

  uint256 private rewardTokenBalance;



  /// @dev Division precision.

  uint256 private precision = 1e12;



  /// @notice Total allocation points. Must be the sum of all allocation points in all pools.

  uint256 public totalAllocPoint;



  /// @notice Pending rewards awaiting for massUpdate.

  uint256 public pendingRewards;



  /// @notice Contract block deployment.

  uint256 public initialBlock;



  /// @notice Time of the contract deployment.

  uint256 public timeDeployed;



  /// @notice Total rewards accumulated since contract deployment.

  uint256 public totalCumulativeRewards;



  /// @notice Reward token.

  address public rewardToken;



  /// @notice Detail of each pool.

  PoolInfo[] public poolInfo;



  /// @notice Detail of each user who stakes tokens.

  mapping(uint256 => mapping(address => UserInfo)) public userInfo;



  constructor(address _rewardToken) public {

    rewardToken = _rewardToken;

    initialBlock = block.number;

    timeDeployed = block.timestamp;

  }



  /// @notice Average fee generated since contract deployment.

  function avgFeesPerBlockTotal() external view returns (uint256 avgPerBlock) {

    return totalCumulativeRewards.div(block.number.sub(initialBlock));

  }



  /// @notice Average fee per second generated since contract deployment.

  function avgFeesPerSecondTotal()

    external

    view

    returns (uint256 avgPerSecond)

  {

    return totalCumulativeRewards.div(block.timestamp.sub(timeDeployed));

  }



  /// @notice Total pools.

  function poolLength() external view returns (uint256) {

    return poolInfo.length;

  }



  /// @notice Display user rewards for a specific pool.

  function pendingReward(uint256 _pid, address _user)

    public

    view

    returns (uint256)

  {

    PoolInfo storage pool = poolInfo[_pid];

    UserInfo storage user = userInfo[_pid][_user];

    uint256 accRewardPerShare = pool.accRewardPerShare;



    return

      user.amount.mul(accRewardPerShare).div(precision).sub(user.rewardDebt);

  }



  /// @notice Add a new pool.

  function add(

    uint256 _allocPoint,

    address _token,

    bool _withUpdate

  ) public onlyOwner {

    if (_withUpdate) {

      massUpdatePools();

    }



    uint256 length = poolInfo.length;



    for (uint256 pid = 0; pid < length; ++pid) {

      require(

        poolInfo[pid].token != _token,

        'TrigRewardsVault: Token pool already added.'

      );

    }



    totalAllocPoint = totalAllocPoint.add(_allocPoint);



    poolInfo.push(

      PoolInfo({token: _token, allocPoint: _allocPoint, accRewardPerShare: 0})

    );

  }



  /// @notice Update the given pool's allocation point.

  function set(

    uint256 _pid,

    uint256 _allocPoint,

    bool _withUpdate

  ) public onlyOwner {

    if (_withUpdate) {

      massUpdatePools();

    }



    totalAllocPoint = totalAllocPoint.sub(poolInfo[_pid].allocPoint).add(

      _allocPoint

    );

    poolInfo[_pid].allocPoint = _allocPoint;

  }



  /// @notice Updates rewards for all pools by adding pending rewards.

  /// Can spend a lot of gas.

  function massUpdatePools() public {

    uint256 length = poolInfo.length;

    uint256 allRewards;



    for (uint256 pid = 0; pid < length; ++pid) {

      allRewards = allRewards.add(_updatePool(pid));

    }



    pendingRewards = pendingRewards.sub(allRewards);

  }



  /// @notice Function that is part of Vault's interface. It must be implemented.

  function update(uint256 amount) external override {

    amount; // silence warning.

    _addPendingRewards();

    massUpdatePools();

  }



  /// @notice Deposit tokens to vault for reward allocation.

  function deposit(uint256 _pid, uint256 _amount) public {

    PoolInfo storage pool = poolInfo[_pid];

    UserInfo storage user = userInfo[_pid][msg.sender];



    massUpdatePools();

    // Transfer pending tokens to user

    _updateAndPayOutPending(_pid, msg.sender);



    //Transfer in the amounts from user

    if (_amount > 0) {

      IERC20(pool.token).safeTransferFrom(

        address(msg.sender),

        address(this),

        _amount

      );

      user.amount = user.amount.add(_amount);

    }



    user.rewardDebt = user.amount.mul(pool.accRewardPerShare).div(precision);

    emit Deposit(msg.sender, _pid, _amount);

  }



  // Withdraw  tokens from Vault.

  function withdraw(uint256 _pid, uint256 _amount) public {

    _withdraw(_pid, _amount, msg.sender, msg.sender);

  }



  // Withdraw without caring about rewards. EMERGENCY ONLY.

  // !Caution this will remove all your pending rewards!

  function emergencyWithdraw(uint256 _pid) public {

    PoolInfo storage pool = poolInfo[_pid];

    UserInfo storage user = userInfo[_pid][msg.sender];



    IERC20(pool.token).safeTransfer(address(msg.sender), user.amount);



    emit EmergencyWithdraw(msg.sender, _pid, user.amount);

    user.amount = 0;

    user.rewardDebt = 0;

    // No mass update dont update pending rewards

  }



  /// @notice Adds any rewards that were sent to the contract since last reward update.

  function _addPendingRewards() internal {

    uint256 newRewards =

      IERC20(rewardToken).balanceOf(address(this)).sub(rewardTokenBalance);



    if (newRewards > 0) {

      rewardTokenBalance = IERC20(rewardToken).balanceOf(address(this));

      pendingRewards = pendingRewards.add(newRewards);

      totalCumulativeRewards = totalCumulativeRewards.add(newRewards);

    }

  }



  // Low level withdraw function

  function _withdraw(

    uint256 _pid,

    uint256 _amount,

    address from,

    address to

  ) internal {

    PoolInfo storage pool = poolInfo[_pid];

    UserInfo storage user = userInfo[_pid][from];

    require(

      user.amount >= _amount,

      'TrigRewardsVault: Withdraw amount is greater than user stake.'

    );



    massUpdatePools();

    _updateAndPayOutPending(_pid, from); // Update balance and claim rewards farmed



    if (_amount > 0) {

      user.amount = user.amount.sub(_amount);

      IERC20(pool.token).safeTransfer(address(to), _amount);

    }



    user.rewardDebt = user.amount.mul(pool.accRewardPerShare).div(precision);

    emit Withdraw(to, _pid, _amount);

  }



  /// @notice Allocates pending rewards to pool.

  function _updatePool(uint256 _pid)

    internal

    returns (uint256 poolShareRewards)

  {

    PoolInfo storage pool = poolInfo[_pid];



    uint256 stakedTokens;



    stakedTokens = IERC20(pool.token).balanceOf(address(this));



    if (totalAllocPoint == 0 || stakedTokens == 0) {

      return 0;

    }



    poolShareRewards = pendingRewards.mul(pool.allocPoint).div(totalAllocPoint);

    pool.accRewardPerShare = pool.accRewardPerShare.add(

      poolShareRewards.mul(precision).div(stakedTokens)

    );

  }



  function _safeRewardTokenTransfer(address _to, uint256 _amount)

    internal

    returns (uint256 _claimed)

  {

    uint256 rewardTokenBal = IERC20(rewardToken).balanceOf(address(this));



    if (_amount > rewardTokenBal) {

      _claimed = rewardTokenBal;

      IERC20(rewardToken).transfer(_to, rewardTokenBal);

      rewardTokenBalance = IERC20(rewardToken).balanceOf(address(this));

    } else {

      _claimed = _amount;

      IERC20(rewardToken).transfer(_to, _amount);

      rewardTokenBalance = IERC20(rewardToken).balanceOf(address(this));

    }

  }



  function _updateAndPayOutPending(uint256 _pid, address _from) internal {

    uint256 pending = pendingReward(_pid, _from);



    if (pending > 0) {

      uint256 _amountClaimed = _safeRewardTokenTransfer(_from, pending);

      emit ClaimedRewards(_from, _pid, _amountClaimed);

    }

  }

}



// File: contracts/TrigRewardsVault.sol







pragma solidity >=0.5.0 <0.7.0;





contract TrigRewardsVault is ERC20Farm {

  constructor(address _rewardToken) public ERC20Farm(_rewardToken) {}

}